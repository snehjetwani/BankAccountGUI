//imports
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import java.io.*;
public class WindowOne extends JFrame implements WindowListener{
  //Invoked when a window is changed from a normal to a minimized state. (From docs.oracle.com)
  public void windowIconified(WindowEvent e){
  }
  //Invoked when a window is changed from a minimized to a normal state. (From docs.oracle.com)
  public void windowDeiconified(WindowEvent e){
  }
  //Invoked when the Window is set to be the active Window. (From docs.oracle.com)
  public void windowActivated(WindowEvent e){
  }
  //Invoked when a Window is no longer the active Window. (From docs.oracle.com)
  public void windowDeactivated(WindowEvent e){
  }
  //objects for specific accounts
  BankAccount savings = new BankAccount("Savings Account", 0, 0, 0);
  BankAccount chequing = new BankAccount("Chequing Account", 0, 0, 0);
  //instances
  private JPanel contentPane;
  private JLabel labelAccount;
  private JLabel labelBalance;
  private JTextField textField;
  static JComboBox accounts;
  private WindowDeposit d;
  private WindowWithdraw w;
  private WindowTransaction t;
  private String name;
//returns current balance in both accounts
public double findBalance(String name){
  double balance = 0;
  if(name.equals("Chequing Account")){
    balance = chequing.balance;
  }else if(name.equals("Savings Account")){
    balance = savings.balance;
  }
  return balance;
//open GUI
}
public static void main(String[] args){
  EventQueue.invokeLater(new Runnable(){
    public void run(){
      try{
        WindowOne frame = new WindowOne();
        frame.setVisible(true);
      }catch(Exception e){
        e.printStackTrace();
      }
    }
  });
}
//convert from .java -> .txt
public void serialize(String name, BankAccount account){
  try{
    if(name.equals("Chequing Account")){
      ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("ChequingAcc.txt"));
      outputStream.writeObject(account);
      outputStream.close();
    }else if(name.equals("Savings Account")){
      ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("SavingsAcc.txt"));
      outputStream.writeObject(account);
      outputStream.close();
    }
  }catch(IOException e){
    System.out.println(e);
  }
}
//convert from .txt -> .java
public BankAccount deserialize(String name){
  BankAccount x = null;
  try{
    if(name.equals("Chequing Account")){
      FileInputStream inputStream = new FileInputStream("ChequingAcc.txt");
      ObjectInputStream reader = new ObjectInputStream(inputStream);
      x = (BankAccount)reader.readObject();
    }
  }catch(IOException e){
    System.out.println(e);
  }catch(ClassNotFoundException e){
    System.out.println(e);
  }
  return x;
}
//deserializing objects depending on their data in .txt files
public WindowOne(){
  if (deserialize("Chequing Account") == null) {
    chequing = new BankAccount("Chequing Account",0,0,0);
  }else{
    chequing = deserialize("Chequing Account");
  }
  if(deserialize("Savings Account") == null){
    savings = new BankAccount("Savings Account",0,0,0);
  }else{
    savings = deserialize("Savings Account");
  }
  name = "Chequing Account";
  setTitle("Corn Nuts Inc.");
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  setBounds(0,0,330,330);
  contentPane = new JPanel();
  contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
  contentPane.setLayout(null);
  setContentPane(contentPane);
  //account title
  labelAccount = new JLabel("Account");
  labelAccount.setHorizontalAlignment(JTextField.CENTER);
  labelAccount.setBounds(60,35,70,70);
  contentPane.add(labelAccount);
  //current balance title
  labelBalance = new JLabel("Current Balance");
  labelBalance.setHorizontalAlignment(JTextField.CENTER);
  labelBalance.setBounds(-30,220,300,10);
  contentPane.add(labelBalance);
  //text field that displays current balance
  textField = new JTextField("");
  textField.setEditable(false);
  textField.setBounds(200,200,100,50);
  contentPane.add(textField);
  textField.setText("$0.00");
  //buttons to allow user to deposit, withdraw or view transactions
  JButton btnDeposit = new JButton("Deposit");
  JButton btnWithdraw = new JButton("Withdraw");
  JButton btnTransactions = new JButton("Transactions");
  btnDeposit.setBounds(30,265,100,20);
  btnWithdraw.setBounds(150,265,110,20);
  btnTransactions.setBounds(95,150,150,20);
  contentPane.add(btnDeposit);
  contentPane.add(btnWithdraw);
  contentPane.add(btnTransactions);
  //options to change accounts
  String [] accountSelect = {"Chequing","Savings"};
  accounts = new JComboBox(accountSelect);
  accounts.setBounds(175,50,100,40);
  contentPane.add(accounts);
//retieve balance from user input and display it
  accounts.addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent e){
      double balance = 0;
      if(accounts.getSelectedItem().equals("Chequing Account")){
        name = "Chequing Account";
        balance = chequing.balance;
      }else if(accounts.getSelectedItem().equals("Savings Account")){
        name = "Savings Account";
        balance = savings.balance;
      }if (balance >= 0){
        textField.setForeground(Color.BLACK);
        textField.setText("$"+String.format("%.2f",balance));
      }else{
        textField.setForeground(Color.RED);
        textField.setText("-$"+String.format("%.2f",Math.abs(balance)));
      }
    }
  });
  //clicking deposit will take user to WindowDeposit
  btnDeposit.addMouseListener(new MouseAdapter(){
    public void mouseClicked(MouseEvent e){
      openWindowDeposit();
    }
  });
  //clicking withdraw will take user to WindowWithdraw
  btnWithdraw.addMouseListener(new MouseAdapter(){
    public void mouseClicked(MouseEvent e){
      openWindowWithdraw();
    }
  });
  //clicking transactions will take user to WindowTransactions
  btnTransactions.addMouseListener(new MouseAdapter(){
    public void mouseClicked(MouseEvent e){
      openWindowTransaction();
    }
  });
  }
  //receives main window events. (click from user)
  public void openWindowDeposit(){
    d = new WindowDeposit(name, chequing, savings);
    d.addWindowListener(this);
    d.setVisible(true);
  }
  public void openWindowWithdraw(){
    w = new WindowWithdraw(name, chequing, savings);
    w.addWindowListener(this);
    w.setVisible(true);
  }
  public void openWindowTransaction(){
    t = new WindowTransaction(name,chequing,savings);
    t.addWindowListener(this);
    t.setVisible(true);
  }
  public void windowOpened(WindowEvent e){
  } 
  //serialize data when window is closed
  public void windowClosing(WindowEvent e){
    serialize("Chequing Account", chequing);
    serialize("Savings Account", savings);
  }
  //if not overdrawn, the current balance for the respective account is black. when overdrawn, the balance will be red and negative.
  public void windowClosed(WindowEvent e){
    if(findBalance(name) >= 0){
      textField.setForeground(Color.BLACK);
      double balance = findBalance(name);
      textField.setText("$" + String.format("%.2f",balance));
    }else{
      textField.setForeground(Color.RED);
      double balance = findBalance(name);
      textField.setText("-$" + String.format("%.2f",Math.abs(balance)));
    }
  }
}