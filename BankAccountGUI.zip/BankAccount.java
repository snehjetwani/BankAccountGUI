//imports
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.text.DecimalFormat;
public class BankAccount{
  //Create your BankAccount object here and run your unit tests!
  //instance Variables
  public String accountNumber;
  public double balance;
  public double withdrawalFee;
  public double annualInterestRate;
//Accessors for accountNumber, balance, withdrawalFee, and annualInterestRate
//Mutators for withdrawalFee and annualInterestRate
public String getAccountNumber(){
  return accountNumber;
}public double getBalance(){
  return balance;
}public double getWithdrawalFee(){
  return withdrawalFee;
}public double getAnnualInterestRate(){
  return annualInterestRate;
}public void setWithdrawalFee(double withdrawalFee){
  this.withdrawalFee = withdrawalFee;
}public void setAnnualInterestRate(double annualInterestRate){
  this.annualInterestRate = annualInterestRate;
//Constructor w/ one parameter
}public BankAccount(String accountNumber){
  this.accountNumber = accountNumber;
//Constructor w/ two parameters
}public BankAccount(String accountNumber, double initialBalance){
  this.accountNumber = accountNumber;
  balance = initialBalance;
//Constructor with all instance variables as parameters
}public BankAccount(String accountNumber, double balance, double withdrawalFee, double annualInterestRate){
  this.accountNumber = accountNumber;
  this.balance = balance;
  this.withdrawalFee = withdrawalFee;
  this.annualInterestRate = annualInterestRate;
//Overloading deposit and withdraw methods
}public ArrayList<Transaction> getTransactions = new ArrayList<Transaction>();
public void deposit(LocalDateTime transactionTime, double amount, String description){
  this.balance += amount;
  getTransactions.add(new Transaction(transactionTime, amount, description));
}public void deposit(double amount, String description){
  this.balance += amount;
  getTransactions.add(new Transaction(amount, description));
}public void withdraw(LocalDateTime transactionTime, double amount, String description){
  balance -= (balance + withdrawalFee);
  getTransactions.add(new Transaction(transactionTime, amount, description));
}public void withdraw(double amount, String description){
balance -= (amount + withdrawalFee);
getTransactions.add(new Transaction(amount, description));
//Arrays to set up transaction list with start and end time
}public ArrayList<Transaction> getTransactions(LocalDateTime startTime, LocalDateTime endTime){
  for(int i = 0; i < (getTransactions.size()-1); i++){
    if((getTransactions.get(i).getTransactionTime()).compareTo(getTransactions.get(i+1).getTransactionTime()) > 0){
      getTransactions.add(getTransactions.get(i));
      getTransactions.remove(i);
    }
  }
  if(startTime == null && endTime == null){
    return getTransactions;
  }else if(startTime == null){
    ArrayList<Transaction> transactionList = new ArrayList<>();
    for (int i = 0; i < getTransactions.size(); i++){
      if ((getTransactions.get(i).getTransactionTime()).compareTo(endTime) <= 0){
        transactionList.add(getTransactions.get(i));
      }
    }
    return transactionList;
  }else if (endTime == null){
    ArrayList<Transaction> transactionList = new ArrayList<>();
    for (int i = 0; i < getTransactions.size(); i++){
      if((getTransactions.get(i).getTransactionTime()).compareTo(startTime) >= 0){
        transactionList.add(getTransactions.get(i));
      }
    }
    return transactionList;
  }else{
    ArrayList<Transaction> transactionList = new ArrayList<>();
    for (int i = 0; i < getTransactions.size(); i++){
      if((getTransactions.get(i).getTransactionTime()).compareTo(startTime) >= 0 && (getTransactions.get(i).getTransactionTime()).compareTo(endTime) <= 0){
        transactionList.add(getTransactions.get(i));
      }
    }
    return transactionList;
  }
  //Changes in account balance
}public void deposit(double amount){
  balance += amount;
  getTransactions.add(new Transaction(amount, "Deposited"));
}public void withdraw(double amount){
  balance -= (amount + withdrawalFee);
  getTransactions.add(new Transaction(amount, "Withdrawn"));
  //Checks to ensure withdrawal<total balance
}public boolean isOverDrawn(){
  if(this.balance < 0){
    return true;
  }else{
    return false;
  }
//Return statement depending on balance.
}public String toString(){
  DecimalFormat df = new DecimalFormat("0.00");
  if (balance >= 0){
   return "BankAccount " + accountNumber + ": " + "$" + df.format(balance);
  }else{
    return "BankAccount " + accountNumber + ": " + "("+"$"+df.format(balance*-1)+")";
  }
}
}