//imports
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.EmptyBorder;

public class WindowWithdraw extends JFrame{
  //instances
  private JPanel contentPane;
  private JTextField textFieldOne;
  private BankAccount chequingAcc;
  private BankAccount savingsAcc;
  private String name;
  //creating frame  
  public WindowWithdraw(String name, BankAccount chequingAcc, BankAccount savingsAcc){
    setTitle("Withdrawals");
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setBounds(0,0,330,330);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5,5,5,5));
    contentPane.setLayout(null);
    setContentPane(contentPane);
    //amount heading
    JLabel labelOne = new JLabel("Amount");
    labelOne.setBounds(60,50,100,100);
    contentPane.add(labelOne);
    //text field for user to type amount
    textFieldOne = new JTextField();
    textFieldOne.setBounds(150,90,100,20);
    contentPane.add(textFieldOne);
    //withdraws money and takes user to windowOne
    JButton btnFinish = new JButton("Finish");
    btnFinish.addMouseListener(new MouseAdapter(){
      public void mouseClicked(MouseEvent e){
        calculate();
      }
    });
    btnFinish.setBounds(170,230,100,30);
    contentPane.add(btnFinish);
    //takes user to WindowOne
    JButton btnCancel = new JButton("Cancel");
    btnCancel.addMouseListener(new MouseAdapter(){
      public void mouseClicked(MouseEvent e){
        returnHome();
      }
    });
    btnCancel.setBounds(20,230,100,30);
    contentPane.add(btnCancel);

    this.chequingAcc = chequingAcc;
    this.savingsAcc = savingsAcc;
    this.name = name;
    //removes money from pre-existing balance. displayed on WindowOne
  }
  public void calculate(){
    double currentBalance = Double.valueOf(textFieldOne.getText());
    if(name.equals("Chequing Account")){
      chequingAcc.withdraw(currentBalance,"Withdraw");
    }else{
      savingsAcc.withdraw(currentBalance,"Withdraw");
    }
    dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
  }
  //return to WindowOne
  public void returnHome(){
    dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
  }
}