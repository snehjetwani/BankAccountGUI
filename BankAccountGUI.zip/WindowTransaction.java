//imports
import javax.swing.*;
import java.awt.event.*;
import java.time.*;
import java.time.format.*;
import java.util.ArrayList;
import javax.swing.border.EmptyBorder;
public class WindowTransaction extends JFrame{
  //instances
  private JPanel contentPane;
  private JLabel endTime;
  private JTextField textFieldOne;
  private JTextField textFieldTwo;
  private BankAccount chequingAcc;
  private BankAccount savingsAcc;
  private String accName;
  private JTextArea transactions;
  private JScrollPane scrollPane;
  public WindowTransaction(String accName, BankAccount chequingAcc, BankAccount savingsAcc){
    //creating frame
    setTitle("Transaction History");
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setBounds(0,0,400,400);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5,5,5,5));
    contentPane.setLayout(null);
    setContentPane(contentPane);
    this.accName = accName;
    this.chequingAcc = chequingAcc;
    this.savingsAcc = savingsAcc;

    JLabel lblStart = new JLabel("Start Time");
    lblStart.setBounds(10,50,100,20);
    contentPane.add(lblStart);
    endTime = new JLabel("End Time");
    endTime.setBounds(10,80,100,20);
    contentPane.add(endTime);
    //text fields for start and end time
    textFieldOne = new JTextField();
    textFieldOne.setBounds(100,50,100,20);
    contentPane.add(textFieldOne);
    textFieldTwo = new JTextField();
    textFieldTwo.setBounds(100,80,100,20);
    contentPane.add(textFieldTwo);
  //date format
    JLabel date = new JLabel("YYYY-MM-DD");
    date.setBounds(110,50,150,30);
    contentPane.add(date);
    //search button to find past transactions
    JButton btnSearch = new JButton("Search");
    btnSearch.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e){
        find();
      }
    });
    btnSearch.setBounds(250,30,100,46);
    contentPane.add(btnSearch);
    //return to windowOne
    JButton btnCancel = new JButton("Cancel");
    btnCancel.setBounds(120,290,120,25);
    contentPane.add(btnCancel);
    //click command for "Cancel"
     btnCancel.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e){
        returnBack();
      }
    });
    //transactions list is a scrollable, uneditable area
    transactions = new JTextArea();
    transactions.setEditable(false);
    scrollPane = new JScrollPane(transactions);
    scrollPane.setBounds(10,100,300,180);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    contentPane.add(scrollPane);
  }
  //use user input to find past transactions
  public void find(){
    transactions.setText("");
    ArrayList<Transaction> allTrans = new ArrayList();
    String userStartTime = String.valueOf(textFieldOne.getText());
    String userEndTime = String.valueOf(textFieldTwo.getText());
    DateTimeFormatter userDate = DateTimeFormatter.ofPattern("YYYY-MM-DD");

    if(userStartTime.equals("")){
      userStartTime = null;
    }
    if(userEndTime.equals("")){
      userEndTime = null;
    }
    //if user enters start and end time, then their inputs are parsed into LocalDateTime variables, which can be used to retrieve past transactions
    if(userStartTime != null && userEndTime != null){
      LocalDate startDate = LocalDate.parse(userStartTime, userDate);
      LocalDate endDate = LocalDate.parse(userEndTime, userDate);
      LocalDateTime startDateTime = LocalDateTime.of(startDate, LocalDateTime.now().toLocalTime());
      LocalDateTime endDateTime = LocalDateTime.of(endDate, LocalDateTime.now().toLocalTime());
      //storing transactions as an array into allTrans
      if(accName.equals("Chequing Account")){
        ArrayList<Transaction> transactions = chequingAcc.getTransactions(startDateTime,endDateTime);
        allTrans = transactions;
      }else if (accName.equals("Savings Account")){
        ArrayList<Transaction> transactions = savingsAcc.getTransactions(startDateTime,endDateTime);
        allTrans = transactions;
      }
      //if user only enters start time, then end time is null
    }else if(userStartTime != null && userEndTime == null){
      //only start time is parsed
        LocalDate startDate = LocalDate.parse(userStartTime, userDate);
        LocalDateTime startDateTime = LocalDateTime.of(startDate, LocalDateTime.now().toLocalTime());
        if(accName.equals("Chequing Account")){
        ArrayList<Transaction> transactions = chequingAcc.getTransactions(startDateTime,null);
        allTrans = transactions;
      }else if (accName.equals("Savings Account")){
        ArrayList<Transaction> transactions = savingsAcc.getTransactions(startDateTime,null);
        allTrans = transactions;
      }
      //if user only enters end time, then start time is null
    }else if(userStartTime == null && userEndTime != null){
      //only end time is parsed
      LocalDate endDate = LocalDate.parse(userEndTime, userDate);
        LocalDateTime endDateTime = LocalDateTime.of(endDate, LocalDateTime.now().toLocalTime());
        if(accName.equals("Chequing Account")){
        ArrayList<Transaction> transactions = chequingAcc.getTransactions(null,endDateTime);
        allTrans = transactions;
      }else if (accName.equals("Savings Account")){
        ArrayList<Transaction> transactions = savingsAcc.getTransactions(null,endDateTime);
        allTrans = transactions;
      }
      //nothing is parsed if start and end time are null
    }else if(userStartTime == null && userEndTime == null){
      if(accName.equals("Chequing Account")){
        ArrayList<Transaction> transactions = chequingAcc.getTransactions(null,null);
        allTrans = transactions;
      }else if (accName.equals("Savings Account")){
        ArrayList<Transaction> transactions = savingsAcc.getTransactions(null,null);
        allTrans = transactions;
      }
    }
    //output date & time pattern
    DateTimeFormatter format = DateTimeFormatter.ofPattern("YYYY-MM-DD HH:mm");
    //loop to output all transactions in transactions area
    for(int i = 0; i < allTrans.size(); i++){
      //displays String balance rounded to 2 decimal places
      double balance1 = allTrans.get(i).getAmount();
      String finalBalance = String.format("%.2f",balance1);
      //output format
      transactions.append(allTrans.get(i).getDescription() + ": " + allTrans.get(i).getTransactionTime().format(format) + ": $" + finalBalance + "\n");
    }
  } 
  //return to WindowOne
  public void returnBack(){
    dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
  }
}