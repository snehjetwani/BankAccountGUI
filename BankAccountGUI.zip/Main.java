class Main {
  public static void main(String[] args) {
    //UPLOAD YOUR ORIGINAL BankAccount.java files here and then create your GUI.
    WindowOne.main(args);
  }
}