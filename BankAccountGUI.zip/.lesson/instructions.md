# Introduction

In this assignment, you will create an application with a functional GUI (Graphical User Interface) that models a bank machine.

# Objective

Your application will re-use the BankAccount class that we created near the beginning of the course in the Object Oriented Programming 1 module. It will allow the user to interact (i.e. make withdrawals or deposits) on multiple bank accounts.

![A](A.jpg)

![B](B.jpg)

## Specifications

- A basic implementation for the interface above is considered to be a 'competent' project (i.e. 60%)
  - Properly validate all user input through the use of dialogs
  - Chequing and Savings account balances are correctly updated
- To achieve proficient (i.e. 80%) for this project, your application will need to
  - Use a dropbox instead of radio buttons to select the account
  - Show the balance in red if overdrawn
- To achieve mastered (i.e. 100%) for this project, your application will need to
  - Implement a data layer to persist the current balance and all transactions made on your accounts
  - Allow the user to browse transactions made on an account on a date range (note that you will need to use your extended BankAccount class for this)

**Note:** Please see Java Swing Tutorial 2 code and powerpoint
